﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Xml.Linq;
using System.Web.Routing;
using System.Web.UI;

namespace SimpleRoutingTest
{
	public class Global : System.Web.HttpApplication
	{
		public static void RegisterRoutes( RouteCollection routes )
		{
			// Note: Change the URL to "{controller}.mvc/{action}/{id}" to enable
			//       automatic support on IIS6 and IIS7 classic mode

			var searchHandler = new WebFormRouteHandler<Page>( "~/Search.aspx" );

			routes.Add( new Route( "category/{category}/Cars", searchHandler ) );
			routes.Add( new Route( "category/{category}/Boats", searchHandler ) );
			routes.Add( new Route( "category/{category}/Planes", searchHandler ) );

			var detailsHandler = new WebFormRouteHandler<Page>( "~/Details.aspx" );

			routes.Add( new Route( "category/{category}/Cars/{id}", detailsHandler ) );
			routes.Add( new Route( "category/{category}/Boats/{id}", detailsHandler ) );
			routes.Add( new Route( "category/{category}/Planes/{id}", detailsHandler ) );
		}

		protected void Application_Start( object sender, EventArgs e )
		{
			RegisterRoutes( RouteTable.Routes );
		}

		protected void Session_Start( object sender, EventArgs e )
		{

		}

		protected void Application_BeginRequest( object sender, EventArgs e )
		{

		}

		protected void Application_AuthenticateRequest( object sender, EventArgs e )
		{

		}

		protected void Application_Error( object sender, EventArgs e )
		{

		}

		protected void Session_End( object sender, EventArgs e )
		{

		}

		protected void Application_End( object sender, EventArgs e )
		{

		}
	}
}