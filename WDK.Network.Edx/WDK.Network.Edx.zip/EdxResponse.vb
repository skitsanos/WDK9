Public Structure EdxResponse
    Public Status As Integer
    Public Message As String
End Structure