Public Structure EdxRequest
    Public Headers As EdxHeaders
    Public Document As Xml.XmlDocument
    Public Body As String
    Public Attachments As EdxFiles
End Structure