Public Structure EdxHeader
    Public Name As String
    Public Value As String
End Structure
