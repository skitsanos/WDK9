Public Structure EdxFile
    Public File As String
    Public Tag As String
    Public Content As String
End Structure
